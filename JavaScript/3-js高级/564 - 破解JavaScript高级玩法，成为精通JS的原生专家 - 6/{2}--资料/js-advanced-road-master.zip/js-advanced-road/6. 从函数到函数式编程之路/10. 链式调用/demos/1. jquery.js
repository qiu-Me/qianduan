$(".testNode")
    .css('color','red')
    .show(200)
    .removeClass('class1');



    
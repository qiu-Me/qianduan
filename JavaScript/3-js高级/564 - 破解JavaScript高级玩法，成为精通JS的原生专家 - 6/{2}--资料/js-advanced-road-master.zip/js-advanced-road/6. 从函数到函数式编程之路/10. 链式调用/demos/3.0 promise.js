
fetch(url)
    .then(res => res.json())
    .then(result => { })
    .then(result => { })
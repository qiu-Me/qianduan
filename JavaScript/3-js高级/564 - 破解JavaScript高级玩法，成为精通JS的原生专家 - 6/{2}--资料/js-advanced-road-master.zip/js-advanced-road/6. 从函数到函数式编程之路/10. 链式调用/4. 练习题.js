MyQuery(".myclass")
    .addClass("classA")
    .style({ height: "100px" })
    .attr("title", "哈哈")
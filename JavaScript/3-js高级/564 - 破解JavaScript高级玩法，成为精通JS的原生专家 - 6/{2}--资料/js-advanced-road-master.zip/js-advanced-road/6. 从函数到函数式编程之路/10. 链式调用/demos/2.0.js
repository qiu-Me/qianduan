[1,2,3,4]
    .filter(filterFn)
    .map(mapFn)
    .join("")


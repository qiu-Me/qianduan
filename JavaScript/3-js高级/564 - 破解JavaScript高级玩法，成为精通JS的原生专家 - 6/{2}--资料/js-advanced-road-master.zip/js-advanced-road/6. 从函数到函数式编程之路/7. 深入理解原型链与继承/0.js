function A(){}
A.__proto__.__proto__.__proto__
var obj = {};

var log = console.log;

log(obj.__proto__.__proto__)
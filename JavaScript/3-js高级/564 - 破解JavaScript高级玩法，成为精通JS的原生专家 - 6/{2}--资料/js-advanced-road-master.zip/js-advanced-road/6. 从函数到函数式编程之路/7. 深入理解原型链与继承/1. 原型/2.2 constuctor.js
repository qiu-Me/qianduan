var obj = {};

console.log(obj.constructor === Object);
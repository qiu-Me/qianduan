function sum(num1, num2) {
    return num1 + num2;
}

console.log("length:", sum.length);
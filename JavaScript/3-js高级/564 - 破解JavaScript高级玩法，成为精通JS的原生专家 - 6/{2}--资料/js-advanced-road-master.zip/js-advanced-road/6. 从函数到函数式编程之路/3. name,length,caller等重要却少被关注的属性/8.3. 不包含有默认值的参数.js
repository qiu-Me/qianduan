function sum(num1 = 1, num2 = 1) {
    return num1 + num2;
}

console.log("length:", sum.length);

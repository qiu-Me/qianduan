function sum(num1, num2 = 1, num3) {
    return num1 + num2 + num3;
}

console.log("length:", sum.length);

var hasStrictMode = (function(){ 
 "use strict";
 return this == undefined;
}());

console.log(hasStrictMode);
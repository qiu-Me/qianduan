var num=1;
{
    num = 2;
    var num;
}
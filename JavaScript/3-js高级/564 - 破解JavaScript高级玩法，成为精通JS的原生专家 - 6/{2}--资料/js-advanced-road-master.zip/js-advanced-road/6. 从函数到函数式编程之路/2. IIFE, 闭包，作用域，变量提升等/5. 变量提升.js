console.log("num1=", num1);
console.log("num2=", num2);

var num1 = 1;
var num2 = 2;

console.log("num1=", num1);
console.log("num2=", num2);

// ==> 等价于
// var num1;
// var num2;

// console.log("num1=",num1);
// console.log("num2=",num2);
// num1=1;
// num2=2;




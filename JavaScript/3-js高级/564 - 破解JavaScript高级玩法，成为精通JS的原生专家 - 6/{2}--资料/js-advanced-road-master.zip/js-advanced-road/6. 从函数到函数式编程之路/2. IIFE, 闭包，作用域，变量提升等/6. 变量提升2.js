
console.log("name:", name);

var name = "name";
function name(){
    console.log("name")
}
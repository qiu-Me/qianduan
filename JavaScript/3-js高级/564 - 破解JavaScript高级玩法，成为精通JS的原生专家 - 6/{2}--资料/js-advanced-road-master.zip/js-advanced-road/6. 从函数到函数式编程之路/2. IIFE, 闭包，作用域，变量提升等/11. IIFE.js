(function(num1,num2){
    console.log(num1+num2);
})(7,9);

(function(num1,num2){
    console.log(num1+num2);
}(7,9));


- function (num1,num2){
    console.log(num1+num2);
}(7,9)
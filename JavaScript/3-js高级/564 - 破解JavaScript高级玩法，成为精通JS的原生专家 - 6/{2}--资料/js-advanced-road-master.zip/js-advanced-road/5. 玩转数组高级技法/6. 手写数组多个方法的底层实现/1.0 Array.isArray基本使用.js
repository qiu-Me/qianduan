const arr = ["1"];

const log = console.log;
log("isArray:", Array.isArray(arr))

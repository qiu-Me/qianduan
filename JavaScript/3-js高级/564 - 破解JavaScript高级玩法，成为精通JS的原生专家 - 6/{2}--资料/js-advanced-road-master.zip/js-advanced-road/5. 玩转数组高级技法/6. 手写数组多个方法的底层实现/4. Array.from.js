


console.log("Array.from:", Array.from({}));
console.log("Array.from:", Array.from(""));
console.log("Array.from:", Array.from({ a: 1, length: "10" }));
console.log("Array.from:", Array.from({ a: 1, length: "ss" }));
console.log("Array.from:", Array.from([NaN,null,undefined,0]));



// console.log("Array.from:", Array.from({ 0: 1, 1: 2, length: max - 1 }));

// console.log("Array.from:", Array.from({ 0: 1, 1: 2, length: max }));

console.log("Array.from: end")

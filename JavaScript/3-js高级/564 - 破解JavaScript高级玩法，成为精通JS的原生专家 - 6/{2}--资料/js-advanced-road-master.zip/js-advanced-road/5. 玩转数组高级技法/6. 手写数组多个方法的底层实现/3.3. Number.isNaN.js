console.log("Number. {}",Number.isNaN({}));
console.log("Number.isNaN 'Hello'",Number.isNaN('hello'));
console.log("Number.isNaN '123'",Number.isNaN('123'));
console.log("Number.isNaN undefined",Number.isNaN(undefined));
console.log("Number.isNaN 'NaN'",Number.isNaN('NaN'));
console.log("Number.isNaN NaN",Number.isNaN(NaN));
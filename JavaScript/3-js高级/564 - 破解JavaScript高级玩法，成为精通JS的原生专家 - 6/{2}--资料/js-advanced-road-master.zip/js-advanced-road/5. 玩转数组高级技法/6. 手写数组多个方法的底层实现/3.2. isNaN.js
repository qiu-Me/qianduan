console.log("isNaN {}",isNaN({}));
console.log("isNaN 'Hello'",isNaN('hello'));
console.log("isNaN '123'",isNaN('123'));
console.log("isNaN undefined",isNaN(undefined));
console.log("isNaN 'NaN'",isNaN('NaN'));
console.log("isNaN NaN",isNaN(NaN));




const arr = [1, 2, 3];
arr.splice(0);
console.log("splice:", arr);


const arr1 = [1, 2, 3];
arr1.length = 0;
console.log("length:", arr1); 
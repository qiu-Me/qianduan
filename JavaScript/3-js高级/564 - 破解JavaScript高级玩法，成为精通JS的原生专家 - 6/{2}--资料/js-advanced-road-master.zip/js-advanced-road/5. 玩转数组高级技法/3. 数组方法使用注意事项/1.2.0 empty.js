const arr2 = [1, ,];

console.log("arr2", arr2);
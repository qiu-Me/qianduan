const array=[1,2,3,4,5,6,7,8,9,10];
array.sort();
console.log("array sort:",array);

console.log("10:".charCodeAt());
console.log("1:".charCodeAt());

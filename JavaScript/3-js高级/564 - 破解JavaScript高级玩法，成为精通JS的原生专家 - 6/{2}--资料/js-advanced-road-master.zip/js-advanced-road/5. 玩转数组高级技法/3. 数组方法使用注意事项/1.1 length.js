
const arr1 = [1,];
const arr2 = [1, ,];
const arr3 = new Array('10');
const arr4 = new Array(10);

console.log("arr1 length: " + arr1.length);
console.log("arr2 length: " + arr2.length);
console.log("arr3 length: " + arr3.length);
console.log("arr4 length: " + arr4.length)
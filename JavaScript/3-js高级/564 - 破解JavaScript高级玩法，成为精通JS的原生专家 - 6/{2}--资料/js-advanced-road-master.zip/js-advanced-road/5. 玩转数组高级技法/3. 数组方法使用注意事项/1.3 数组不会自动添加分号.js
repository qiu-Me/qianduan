// const objA = { a: 1 }
// ['a']

// console.log(objA);

// const objB = ['a']
// ['a']

// console.log(objB);


var a = [[1, 2], 2, 3]
console.log(a);
[0, 2, 3].map(v => console.log(v * v))
console.log(a)

// =>
// var a = [[1,2],2,3]
// console.log(a);
// [0,2,3].map(v=> console.log(v*v))
// console.log(a)
const array = [1, 2, 3, 4, 5];
delete array[2];
console.log("delete array:", array);
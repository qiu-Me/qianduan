

var arr = [0, 1, 2, 3, 4];

console.log(arr["2"]);
console.log(arr["3"]);
console.log(arr["4"]);
// Array 
let arr = [1, 2, 5]
// Object 
let user = {
    name: "Jason",
    age: 24
}
// Date 返回时间撮
let now = new Date()
// Function
function fun() {
    return 10;
}

console.log("Array:", arr.valueOf())
console.log("Object:", user.valueOf())
console.log("Date:", now.valueOf())
console.log("Function:", fun.valueOf()) 

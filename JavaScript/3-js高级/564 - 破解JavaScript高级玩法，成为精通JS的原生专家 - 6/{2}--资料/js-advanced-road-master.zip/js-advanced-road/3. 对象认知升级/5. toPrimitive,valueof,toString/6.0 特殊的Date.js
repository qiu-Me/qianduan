const date = new Date();


console.log("date toString:", date.toString())
console.log("date valueOf:", date.valueOf())



console.log(`date number:`, + date)
console.log(`date str:`, `${date}`)


console.log(`date +:`, date + 1)
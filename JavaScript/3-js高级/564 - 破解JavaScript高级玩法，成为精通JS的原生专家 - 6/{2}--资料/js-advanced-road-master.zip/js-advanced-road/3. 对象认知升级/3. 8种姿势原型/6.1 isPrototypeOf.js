
const print = console.log;

print(Object.isPrototypeOf({}))
print(Object.prototype.isPrototypeOf({}))
print(Reflect.isPrototypeOf({}))
print(Function.isPrototypeOf({}))
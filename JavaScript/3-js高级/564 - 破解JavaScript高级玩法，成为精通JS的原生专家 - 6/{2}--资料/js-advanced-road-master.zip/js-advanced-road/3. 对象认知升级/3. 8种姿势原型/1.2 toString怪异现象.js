

var proto = Boolean.prototype
console.log(typeof proto);
console.log(Object.prototype.toString.call(proto));
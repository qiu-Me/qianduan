const obj = {};
Object.defineProperty(obj, "name", {
	value: "哈士奇"
});

console.log("name:", obj.name)

const deepClone = function (obj) {
    return JSON.parse(JSON.stringify(obj))
}


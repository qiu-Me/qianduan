
var obj = {
    name:"tom",
    [Symbol.for("sex")]: 1
}

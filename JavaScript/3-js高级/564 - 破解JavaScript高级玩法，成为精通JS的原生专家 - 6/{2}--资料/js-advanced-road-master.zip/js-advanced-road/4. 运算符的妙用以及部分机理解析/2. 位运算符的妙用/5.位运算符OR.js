console.log("5 | 5==",5 | 5);
console.log("0 | 0==",0 | 0);
console.log("-1| -1==",-1 | -1);


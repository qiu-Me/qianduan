console.log("5 ^ 5==",5 ^ 5)
console.log("5 ^ 4==",5 ^ 4)

console.log("25 ^ 4==",25 ^ 4)
console.log("25 ^ 25==",25 ^ 25)

console.log("0 ^ 0==",0 ^ 0)


console.log("0 ^ 1==",0 ^ 1)

console.log("1 ^ 0==",1 ^ 0)
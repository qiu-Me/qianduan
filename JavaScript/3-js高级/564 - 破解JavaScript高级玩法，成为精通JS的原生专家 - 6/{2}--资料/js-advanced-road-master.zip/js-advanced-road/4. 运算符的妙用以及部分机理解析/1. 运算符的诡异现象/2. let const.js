// 浏览器中执行

var nameVar = "nameVar";
let nameLet = "nameLet";
const nameConst = "nameConst";

console.log("nameVar:", window.nameVar);
console.log("nameLet:", window.nameLet);
console.log("nameConst:", window.nameConst);
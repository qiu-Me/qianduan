delete 10; //true

var trees = ["redwood","bay","cedar","oak","maple"];
delete trees[3];
console.log("trees:",trees);
// trees：：：  ["redwood", "bay", "cedar", empty, "maple"]


delete {}


var x = 1;
delete x


// 浏览器中运行
var x = 1;
delete window.x;
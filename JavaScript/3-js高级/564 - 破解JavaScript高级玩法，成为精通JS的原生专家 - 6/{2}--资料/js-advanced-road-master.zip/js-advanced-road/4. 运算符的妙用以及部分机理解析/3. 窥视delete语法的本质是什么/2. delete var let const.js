//var 
function testVar() {
    var a = 1;
    console.log("delete var a:", delete a);
    console.log("var a :", a);
}
testVar();

//let const,
function testLet() {
    let a = 1;
    console.log("delete let a:", delete a);
    console.log("let a :", a);
}
//作用域在testLet 中
testLet();







console.log((0.30000000000000004).toString(2))
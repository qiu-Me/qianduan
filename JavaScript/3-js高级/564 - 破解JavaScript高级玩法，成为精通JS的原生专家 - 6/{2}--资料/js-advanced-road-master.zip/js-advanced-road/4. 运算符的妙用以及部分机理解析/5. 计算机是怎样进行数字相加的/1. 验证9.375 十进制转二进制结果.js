console.log((9.375).toString(2))
console.log(Number.prototype.toString.call(9.375, 2))
console.log(Number.prototype.toString.call(Number(9.375), 2))


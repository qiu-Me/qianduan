String.prototype.constructor = function a() {
    return {}
}
console.log("a".constructor)
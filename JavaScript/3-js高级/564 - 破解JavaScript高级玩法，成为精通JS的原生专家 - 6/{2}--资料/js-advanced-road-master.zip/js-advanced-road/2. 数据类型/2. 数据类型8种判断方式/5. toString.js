

const pf = console.log;

pf(typeof Boolean.prototype)
pf(Object.prototype.toString.call(Boolean.prototype))
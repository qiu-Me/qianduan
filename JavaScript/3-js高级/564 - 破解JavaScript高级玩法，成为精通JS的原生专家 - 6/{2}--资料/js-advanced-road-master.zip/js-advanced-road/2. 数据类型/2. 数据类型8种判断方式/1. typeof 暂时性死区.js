function log(){
    typeof a
    let a = 10;
}

log();
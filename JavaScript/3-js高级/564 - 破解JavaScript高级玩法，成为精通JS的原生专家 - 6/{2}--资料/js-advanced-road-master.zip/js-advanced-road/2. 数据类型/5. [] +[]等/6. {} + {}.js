// []  ''
// {}  '[object object]'

// {} + {};
// + '[object Object]'
// NaN

// 10n + 10

Symbol.for("a") + 10
// []  ''
// {}  '[object object]'


// [] +  []
// [].toString() + [].toString()
// '' + ''
// ''

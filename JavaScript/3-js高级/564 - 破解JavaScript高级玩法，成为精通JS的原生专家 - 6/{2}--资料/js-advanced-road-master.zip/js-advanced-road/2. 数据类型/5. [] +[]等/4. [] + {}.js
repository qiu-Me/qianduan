// []  ''
// {}  '[object object]'

//  [] + {};
//  [].toString() + {}.toString()
// '[object object]' + ''
// '[object object]'

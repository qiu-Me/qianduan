// 类型标记位
// 000： object  
// 001： integer   
// 010： double   
// 100： string   
// 110： boolean
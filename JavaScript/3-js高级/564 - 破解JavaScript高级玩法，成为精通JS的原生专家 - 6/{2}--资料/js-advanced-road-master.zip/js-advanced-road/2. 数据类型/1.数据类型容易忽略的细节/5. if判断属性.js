

const result = {};
// name存在
if(obj.name){
    result.name = obj.name;
}
return result;

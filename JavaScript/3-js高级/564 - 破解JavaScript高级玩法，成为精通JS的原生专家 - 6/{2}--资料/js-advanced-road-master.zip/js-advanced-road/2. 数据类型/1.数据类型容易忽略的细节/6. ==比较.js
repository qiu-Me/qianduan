
console.log(null == 0)
console.log('0' == false)